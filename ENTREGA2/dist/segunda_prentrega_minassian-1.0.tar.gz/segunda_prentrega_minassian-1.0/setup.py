from setuptools import setup

setup (
    name = "segunda_prentrega_minassian",
    version = "1.0",
    description = "Paquete segunda entrega",
    author = "Paula Minassian",
    author_email = "pau.m-v@hotmail.com",
    
    
    packages = ["segunda_prentrega_minassian"]
    
)